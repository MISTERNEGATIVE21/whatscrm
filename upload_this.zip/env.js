const appVersion = "1.8"

module.exports = { appVersion }